package com.example.firehome

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var pendingUpdate: Runnable? = null
    private var currentApp: AppEntry? = null

    private lateinit var repo: ShortcutsRepo
    private lateinit var backdrop: ImageView
    private lateinit var appBar: RecyclerView
    private lateinit var previewRow: RecyclerView
    private val previewAdapter = PreviewAdapter { openPreview(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repo = ShortcutsRepo(this)
        backdrop = findViewById(R.id.backdrop)
        appBar = findViewById(R.id.appBar)
        previewRow = findViewById(R.id.previewRow)
        previewRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        previewRow.adapter = previewAdapter

        appBar.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        appBar.adapter = AppAdapter(loadApps(), ::onAppFocused, ::launch)

        // Start with focus on the first app so its preview shows right away
        appBar.post { appBar.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    override fun onResume() {
        super.onResume()
        repo.reload()
        // Pick up edits to shortcuts.json, but don't yank focus away if the user is browsing the strip
        if (!previewRow.hasFocus()) currentApp?.let { showPreview(it) }
    }

    // We are the home screen: Back should not close anything
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() = Unit

    // --- apps -------------------------------------------------------------

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val seen = HashSet<String>()
        val result = ArrayList<AppEntry>()

        for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val info = ri.activityInfo
                if (info.packageName == packageName || !seen.add(info.packageName)) continue
                val banner = info.loadBanner(pm)
                result.add(
                    AppEntry(
                        label = ri.loadLabel(pm).toString(),
                        packageName = info.packageName,
                        component = ComponentName(info.packageName, info.name),
                        banner = banner ?: ri.loadIcon(pm),
                        hasRealBanner = banner != null
                    )
                )
            }
        }

        // Apps listed in shortcuts.json first (in that order), the rest alphabetically
        val order = repo.order
        return result.sortedWith(
            compareBy<AppEntry>(
                { entry ->
                    val i = order.indexOf(entry.packageName)
                    if (i < 0) Int.MAX_VALUE else i
                },
                { entry -> entry.label.lowercase() }
            )
        )
    }

    private fun launch(app: AppEntry) {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .setComponent(app.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // --- preview rows ----------------------------------------------------

    private fun onAppFocused(app: AppEntry) {
        pendingUpdate?.let { handler.removeCallbacks(it) }
        val update = Runnable { showPreview(app) }
        pendingUpdate = update
        // Small delay so scrolling quickly across the bar doesn't reload everything
        handler.postDelayed(update, 150)
    }

    private fun showPreview(app: AppEntry) {
        currentApp = app
        val preview = repo.previewFor(app.packageName)

        val backdropUrl = preview?.backdrop
        if (backdropUrl != null) {
            backdrop.load(backdropUrl) { crossfade(300) }
        } else {
            backdrop.setImageResource(R.drawable.bg_default)
        }

        val cards = ArrayList<PreviewCard>()
        for (row in preview?.rows.orEmpty()) {
            row.items.forEachIndexed { i, item ->
                cards.add(PreviewCard(item, if (i == 0) row.title else null))
            }
        }
        previewRow.visibility = if (cards.isEmpty()) View.GONE else View.VISIBLE
        previewAdapter.submit(cards)
        previewRow.scrollToPosition(0)
    }

    private fun openPreview(item: PreviewItem) {
        val app = currentApp ?: return
        val link = item.link
        if (link != null) {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse(link))
                        .setPackage(app.packageName)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            } catch (e: Exception) {
                // App doesn't handle that link (ActivityNotFound / Security): just open the app
            }
        }
        launch(app)
    }
}
