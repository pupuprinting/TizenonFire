package com.example.firehome

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Loads the per-app preview rows from shortcuts.json.
 *
 * Lookup order:
 *  1. /sdcard/Android/data/com.example.firehome/files/shortcuts.json  (edit without rebuilding)
 *  2. assets/shortcuts.json                                           (bundled sample)
 */
class ShortcutsRepo(private val context: Context) {

    private var map: Map<String, AppPreview> = emptyMap()

    /** Package names in the order they appear in the JSON (used to sort the app bar). */
    val order: List<String>
        get() = map.keys.filter { it != DEFAULT_KEY }

    init {
        reload()
    }

    fun reload() {
        val text = try {
            val external = File(context.getExternalFilesDir(null), "shortcuts.json")
            if (external.exists()) {
                external.readText()
            } else {
                context.assets.open("shortcuts.json").bufferedReader().use { it.readText() }
            }
        } catch (e: Exception) {
            return
        }
        map = parse(text)
    }

    fun previewFor(packageName: String): AppPreview? = map[packageName] ?: map[DEFAULT_KEY]

    private fun parse(text: String): Map<String, AppPreview> {
        val out = LinkedHashMap<String, AppPreview>()
        try {
            val root = JSONObject(text)
            for (pkg in root.keys()) {
                val appJson = root.getJSONObject(pkg)
                val rows = ArrayList<PreviewRow>()
                val rowsJson = appJson.optJSONArray("rows") ?: JSONArray()
                for (i in 0 until rowsJson.length()) {
                    val rowJson = rowsJson.getJSONObject(i)
                    val items = ArrayList<PreviewItem>()
                    val itemsJson = rowJson.optJSONArray("items") ?: JSONArray()
                    for (j in 0 until itemsJson.length()) {
                        val itemJson = itemsJson.getJSONObject(j)
                        items.add(
                            PreviewItem(
                                title = itemJson.optString("title", ""),
                                image = itemJson.str("image"),
                                badge = itemJson.str("badge"),
                                progress = itemJson.optInt("progress", -1).takeIf { it in 0..100 },
                                link = itemJson.str("link")
                            )
                        )
                    }
                    rows.add(PreviewRow(rowJson.optString("title", ""), items))
                }
                out[pkg] = AppPreview(appJson.str("backdrop"), rows)
            }
        } catch (e: Exception) {
            // Malformed JSON: keep whatever was parsed so far
        }
        return out
    }

    private fun JSONObject.str(key: String): String? {
        val value = optString(key, "")
        return if (value.isEmpty()) null else value
    }

    companion object {
        const val DEFAULT_KEY = "_default"
    }
}
