package com.example.firehome

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

/**
 * Focus effect: the card grows and lifts (shadow), and its row item is raised above its
 * neighbours so the enlarged card is never covered by the next tile.
 */
private fun animateFocus(root: View, card: View, focused: Boolean, scale: Float) {
    val target = if (focused) scale else 1f
    val lift = if (focused) 10f * card.resources.displayMetrics.density else 0f
    card.animate().scaleX(target).scaleY(target).translationZ(lift).setDuration(120).start()
    root.translationZ = if (focused) 1f else 0f
}

/** Bottom bar: one tile per installed app. */
class AppAdapter(
    private val apps: List<AppEntry>,
    private val onFocused: (AppEntry) -> Unit,
    private val onClick: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val card: View = view.findViewById(R.id.card)
        val banner: ImageView = view.findViewById(R.id.banner)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount(): Int = apps.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = apps[position]
        holder.banner.setImageDrawable(app.banner)
        holder.banner.scaleType =
            if (app.hasRealBanner) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.CENTER_INSIDE
        holder.label.text = app.label
        holder.label.visibility = if (app.hasRealBanner) View.GONE else View.VISIBLE
        holder.itemView.setOnClickListener { onClick(app) }
        holder.itemView.setOnFocusChangeListener { v, focused ->
            animateFocus(v, holder.card, focused, 1.14f)
            if (focused) onFocused(app)
        }
    }
}

/** The strip above the bar: suggested content for the focused app, with section headings. */
class PreviewAdapter(
    private val onClick: (PreviewItem) -> Unit
) : RecyclerView.Adapter<PreviewAdapter.VH>() {

    private var cards: List<PreviewCard> = emptyList()

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val section: TextView = view.findViewById(R.id.section)
        val card: View = view.findViewById(R.id.card)
        val image: ImageView = view.findViewById(R.id.image)
        val title: TextView = view.findViewById(R.id.title)
        val captionScrim: View = view.findViewById(R.id.captionScrim)
        val badge: TextView = view.findViewById(R.id.badge)
        val progress: ProgressBar = view.findViewById(R.id.progress)
    }

    fun submit(newCards: List<PreviewCard>) {
        cards = newCards
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_preview, parent, false))

    override fun getItemCount(): Int = cards.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val card = cards[position]
        val item = card.item

        holder.section.text = card.section.orEmpty()
        holder.section.visibility = if (card.section == null) View.INVISIBLE else View.VISIBLE

        val imageUrl = item.image
        if (imageUrl != null) {
            holder.image.load(imageUrl) { crossfade(true) }
        } else {
            holder.image.setImageDrawable(null)
        }
        holder.title.text = item.title
        holder.title.visibility = if (imageUrl == null) View.VISIBLE else View.GONE

        // "Continue watching" style: white caption on a dark gradient + progress bar.
        // Everything else with a badge gets the red pill ("New Season").
        val resume = item.progress != null
        holder.progress.visibility = if (resume) View.VISIBLE else View.GONE
        holder.progress.progress = item.progress ?: 0
        holder.captionScrim.visibility = if (resume && item.badge != null) View.VISIBLE else View.GONE
        holder.badge.text = item.badge
        holder.badge.visibility = if (item.badge == null) View.GONE else View.VISIBLE
        holder.badge.setBackgroundResource(if (resume) 0 else R.drawable.badge_bg)

        holder.itemView.contentDescription = item.title
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnFocusChangeListener { v, focused ->
            animateFocus(v, holder.card, focused, 1.08f)
        }
    }
}
