package com.example.firehome

import android.content.ComponentName
import android.graphics.drawable.Drawable

data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val banner: Drawable?,
    val hasRealBanner: Boolean
)

data class PreviewItem(
    val title: String,
    val image: String?,
    /** Small caption: "New Season", "Continue Watching"... */
    val badge: String?,
    /** 0..100. When set, the tile shows a "continue watching" caption and a progress bar. */
    val progress: Int?,
    /** Deep link handed to the app when the tile is clicked. */
    val link: String?
)

data class PreviewRow(
    val title: String,
    val items: List<PreviewItem>
)

data class AppPreview(
    val backdrop: String?,
    val rows: List<PreviewRow>
)

/** One tile in the strip. [section] is set on the first tile of each row, like Samsung's headings. */
data class PreviewCard(
    val item: PreviewItem,
    val section: String?
)
